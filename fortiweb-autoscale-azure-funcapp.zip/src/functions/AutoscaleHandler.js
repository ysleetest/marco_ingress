const { app } = require('@azure/functions');
const FwbAutoScaleAzure = require('fortiweb-autoscale-azure');
app.http('AutoscaleHandler', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);

      //  const name = request.query.get('name') || await request.text() || 'world';

        await FwbAutoScaleAzure.initModule(context);
context.log(`H22222 "${request.url}"`);        
        await FwbAutoScaleAzure.handle(context, request);
context.log(`3333 "${request.url}"`);    
        return context.res;            
    //    return { body: `Hello, ${name}!` };
    }
});
