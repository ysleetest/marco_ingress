const { app } = require('@azure/functions');
const FwbAutoScaleAzure = require('fortiweb-autoscale-azure');
app.http('AutoscaleHandler', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);

        const name = request.query.get('name') || await request.text() || 'world';

        await FwbAutoScaleAzure.initModule();
        await FwbAutoScaleAzure.handle(context, req);
      //  return { body: `Hello, ${name}!` };
    }
});
