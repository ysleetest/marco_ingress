//&

/*
 *{
  "disabled": false,
  "bindings": [
    {
      "authLevel": "anonymous",
      "type": "httpTrigger",
      "direction": "in",
      "name": "req",
      "methods": [
        "get",
        "post"
      ]
    },
    {
      "type": "http",
      "direction": "out",
      "name": "res"
    }
  ]
}

FortiWeb Autoscale Azure Function (1.0.0-beta)
Author: Fortinet
*/
import {
  app,
  HttpRequest,
  HttpResponseInit,
  InvocationContext,
} from "@azure/functions";

let FwbAutoScaleAzure = require('fortiweb-autoscale-azure');
/**
 * Azure Function App Entry.
 * @param {Object} context Azure Function App runtime context
 * @param {Object} req request object from c
 */
module.exports = async function AutoscaleHandler1(context, req) {
    context.log(`Incoming request: ${JSON.stringify(req)}`);
    await FwbAutoScaleAzure.initModule();
    await FwbAutoScaleAzure.handle(context, req);
};

app.http("AutoscaleHandler", {
  methods: ["GET", "POST"],
  handler: AutoscaleHandler1,
});
